﻿namespace JCSG_Puzzle.Model
{
    using System;
    using System.Drawing;

    internal class Piece
    {
        #region Fields

        /// <summary>
        /// The rotation angle.
        /// </summary>
        public Int32 Angle;

        /// <summary>
        /// The bitmap.
        /// </summary>
        public Bitmap bmp;

        /// <summary>
        /// The display x coordinate.
        /// </summary>
        public Int32 displayX;

        /// <summary>
        /// The display y coordinate.
        /// </summary>
        public Int32 displayY;

        /// <summary>
        /// The X coordinate.
        /// </summary>
        public Int32 X;

        /// <summary>
        /// The Y coordinate.
        /// </summary>
        public Int32 Y;

        #endregion Fields

        #region Methods

        /// <summary>
        /// Returns the fully qualified type name of this instance.
        /// </summary>
        ///
        /// <returns>
        /// The fully qualified type name.
        /// </returns>
        public override String ToString()
        {
            return $"piece R{Y}C{X} @ {Angle}, displayed at R{displayY}C{displayX}";
        }

        #endregion Methods
    }
}