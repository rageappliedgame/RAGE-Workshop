﻿namespace JCSG_Puzzle.Model
{
    using System;

    /// <summary>
    /// A level.
    /// </summary>
    public class Level
    {
        #region Constructors

        /// <summary>
        /// Constructor that prevents a default instance of this class from being created.
        /// </summary>
        public Level()
        {
            // 2x2 by default
            Rows = 2;
            Cols = 2;
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Gets or sets the cols.
        /// </summary>
        ///
        /// <value>
        /// The cols.
        /// </value>
        public Int32 Cols { get; set; }

        /// <summary>
        /// Gets the identifier of the level.
        /// </summary>
        ///
        /// <value>
        /// The identifier of the level.
        /// </value>
        public String LevelID
        {
            get; set;
        }

        /// <summary>
        /// Gets the moves.
        /// </summary>
        ///
        /// <value>
        /// The moves.
        /// </value>
        public Int32 Moves
        {
            get
            {
                return Swaps + Rotates;
            }
        }

        /// <summary>
        /// Gets or sets the rotates.
        /// </summary>
        ///
        /// <value>
        /// The rotates.
        /// </value>
        public Int32 Rotates { get; set; }

        /// <summary>
        /// Gets or sets the rows.
        /// </summary>
        ///
        /// <value>
        /// The rows.
        /// </value>
        public Int32 Rows { get; set; }

        /// <summary>
        /// Gets or sets the swaps.
        /// </summary>
        ///
        /// <value>
        /// The swaps.
        /// </value>
        public Int32 Swaps { get; set; }

        #endregion Properties

        #region Methods

        /// <summary>
        /// Returns a string that represents the current object.
        /// </summary>
        ///
        /// <returns>
        /// A string that represents the current object.
        /// </returns>
        public override String ToString()
        {
            return $"Cols:{Cols}, Rows:{Rows}, Swaps:{Swaps}, Rotates:{Rotates}, Minimal Moves:{Swaps + Rotates}";
        }

        #endregion Methods
    }
}