﻿namespace JCSG_Puzzle
{
    using System;
    using System.IO;
    using System.Text;

    /// <summary>
    /// A fix-up for a .Net 'flaw'. It sets sets the Encoding of Xml written to UTF8 matching the XML
    /// declaration instead of defaulting to UTF-16.
    /// </summary>
    ///
    /// <remarks>
    /// Fix-up for XDocument Serialization defaulting to utf-16 instead of utf-8.
    /// </remarks>
    public class StringWriterUtf8 : StringWriter, IDisposable
    {
        #region Properties

        /// <summary>
        /// Gets the <see cref="T:System.Text.Encoding" /> in which the output is written.
        /// </summary>
        ///
        /// <value>
        /// The Encoding in which the output is written.
        /// </value>
        public override Encoding Encoding
        {
            get
            {
                return Encoding.UTF8;
            }
        }

        #endregion Properties
    }
    /// <summary>
    /// .
    /// </summary>
}
