﻿namespace JCSG_Puzzle
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Drawing;
    using System.Drawing.Imaging;
    using System.Linq;
    using System.Reflection;
    using System.Windows.Forms;

    using JCSG_Puzzle.Model;

    public partial class Puzzle : PictureBox
    {
        #region Fields

        /// <summary>
        /// The message.
        /// </summary>
        private const string Message = "SOLVED !";

        /// <summary>
        /// The scale down images.
        /// </summary>
        private Double ScaleDown = 2;

        /// <summary>
        /// The media.
        /// </summary>
        private List<String> Media = new List<String>();

        /// <summary>
        /// The puzzle image preview timer.
        /// </summary>
        private Timer previewTimer = new Timer();

        /// <summary>
        /// The puzzle Image.
        /// </summary>
        private Bitmap puzzleImage = null;

        /// <summary>
        /// The pieces list.
        /// </summary>
        List<Piece> PuzzlePieces = new List<Piece>();

        /// <summary>
        /// Full pathname of the resource base file.
        /// </summary>
        private String ResourceBasePath = String.Empty;

        /// <summary>
        /// The random generator.
        /// </summary>
        private Random RndGen = new Random();

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Default constructor.
        /// </summary>
        public Puzzle()
        {
            InitializeComponent();

            this.DoubleClick += puzzle_DoubleClick;
            this.MouseDown += puzzle_MouseDown;
            this.DragDrop += puzzle_DragDrop;
            this.DragOver += puzzle_DragOver;
            this.DragEnter += puzzle_DragEnter;
            this.MouseMove += puzzle_MouseMove;

            previewTimer.Interval = 1000;
            previewTimer.Tick += PreviewTimer_Tick;
        }

        #endregion Constructors

        #region Events

        /// <summary>
        /// Event queue for all listeners interested in OnMovePerformed events.
        /// </summary>
        [Category("Puzzle")]
        public event EventHandler OnMovePerformed;

        /// <summary>
        /// Event queue for all listeners interested in OnSolved events.
        /// </summary>
        [Category("Puzzle")]
        public event EventHandler OnSolved;

        #endregion Events

        #region Properties

        /// <summary>
        /// Gets or sets the identifier of the puzzle.
        /// </summary>
        ///
        /// <value>
        /// The identifier of the puzzle.
        /// </value>
        public String PuzzleID { get; private set; }

        /// <summary>
        /// Gets the result.
        /// </summary>
        ///
        /// <value>
        /// The result.
        /// </value>
        public String Result
        {
            get
            {
                if (!IsSolved())
                {
                    return String.Empty;
                }
                else
                {
                    return (this.Moves == this.MyMoves) ? "Perfect score!" : "Solved";
                }
            }
        }

        /// <summary>
        /// Gets the score.
        /// </summary>
        ///
        /// <value>
        /// The score.
        /// </value>
        public String Score
        {
            get
            {
                return $"{MyMoves} of {this.Moves} moves";
            }
        }

        /// <summary>
        /// Gets or sets the number of columns.
        /// </summary>
        ///
        /// <value>
        /// The cols.
        /// </value>
        internal Int32 Cols { get; set; } = 2;

        /// <summary>
        /// Gets the minimal number of moves necessary to solve the puzzle.
        /// </summary>
        ///
        /// <value>
        /// The moves.
        /// </value>
        internal Int32 Moves
        {
            get
            {
                return Swaps + Rotates;
            }
        }

        /// <summary>
        /// Gets or sets the number of moves I made.
        /// </summary>
        ///
        /// <value>
        /// The number of moves I made.
        /// </value>
        internal Int32 MyMoves { get; set; }

        /// <summary>
        /// Gets or sets the number of rotates.
        /// </summary>
        ///
        /// <value>
        /// The rotates.
        /// </value>
        internal Int32 Rotates { get; set; } = 1;

        /// <summary>
        /// Gets or sets the number of rows.
        /// </summary>
        ///
        /// <value>
        /// The rows.
        /// </value>
        internal Int32 Rows { get; set; } = 2;

        /// <summary>
        /// Gets or sets the number of swaps.
        /// </summary>
        ///
        /// <value>
        /// The swaps.
        /// </value>
        internal Int32 Swaps { get; set; } = 1;

        #endregion Properties

        #region Methods

        /// <summary>
        /// Creates a puzzle of a specified level with an random image. It swaps and rotates the number
        /// of pieces as defined in the level. Pieces are only swapped and/or rotated at most once.
        /// </summary>
        ///
        /// <param name="level"> The number of vertical cuts. </param>
        public void CreatePuzzle(Level level)
        {
            this.PuzzleID = level.LevelID;

            this.Rows = level.Rows;
            this.Cols = level.Cols;
            this.Swaps = level.Swaps;
            this.Rotates = level.Rotates;

            this.MyMoves = 0;

            PuzzlePieces.Clear();

            this.Invalidate();

            puzzleImage = new Bitmap(Assembly.GetEntryAssembly().GetManifestResourceStream($"{ResourceBasePath}{Media[RndGen.Next(Media.Count)]}"));

            previewTimer.Start();

            ////! Size pictureBox used for Display;
            ////
            //this.Width = (Int32)(puzzleImage.Width / ScaleDown);
            //this.Height = (Int32)(puzzleImage.Height / ScaleDown);

            //! Create Puzzle.
            //
            PixelFormat format = puzzleImage.PixelFormat;

            //! First fill the Pieces list with unmodified images. Then swap/rotate randomly selected pieces.
            //
            for (Int32 r = 0; r < Rows; r++)
            {
                for (Int32 c = 0; c < Cols; c++)
                {
                    Int32 pw = (puzzleImage.Width / Cols);
                    Int32 ph = (puzzleImage.Height / Rows);

                    Rectangle targetArea = new Rectangle(c * pw, r * ph, pw, ph);
                    Bitmap b = puzzleImage.Clone(targetArea, format);

                    PuzzlePieces.Add(new Piece()
                    {
                        X = c,
                        Y = r,
                        displayX = c,
                        displayY = r,
                        Angle = 0,
                        bmp = b,
                    });
                }
            }

            //! Swap randomly selected Pieces.
            //
            List<Int32> swapsNdx = Enumerable.Range(0, PuzzlePieces.Count).ToList();

            int safeSwaps = Math.Min(Swaps, PuzzlePieces.Count / 2);

            for (int i = 0; i < safeSwaps; i++)
            {
                //! Source
                Int32 src = RndGen.Next(swapsNdx.Count);
                Int32 srcNdx = swapsNdx[src];
                swapsNdx.RemoveAt(src);

                //! Destination
                Int32 dst = RndGen.Next(swapsNdx.Count);
                Int32 dstNdx = swapsNdx[dst];
                swapsNdx.RemoveAt(dst);

                SwapPieces(srcNdx, dstNdx);
            }

            //! Rotates randomly selected Pieces.
            //
            List<Int32> rotatesNdx = Enumerable.Range(0, PuzzlePieces.Count).ToList();

            int safeRotates = Math.Min(Rotates, PuzzlePieces.Count);

            for (int i = 0; i < safeRotates; i++)
            {
                //! Source.
                Int32 src = RndGen.Next(rotatesNdx.Count);
                Int32 srcNdx = rotatesNdx[src];
                rotatesNdx.RemoveAt(src);

                //! Swap Pieces.
                RotatePiece(srcNdx);
            }

            previewTimer.Start();

            //! Diagnostic Dump.
            //
            //foreach (Piece piece in pieces)
            //{
            //    Debug.WriteLine(piece.ToString());
            //}

            //! Enable Drag & Drop.
            //
            this.AllowDrop = true;

            this.Invalidate();
        }

        /// <summary>
        /// Initializes the puzzle. It lists and stores all images resource names from the applications
        /// embedded resources.  
        /// </summary>
        ///
        /// <param name="ResourceBasePath"> Full pathname of the resource base file. </param>
        public void InitPuzzle(String ResourceBasePath)
        {
            this.ResourceBasePath = ResourceBasePath;

            //! Clear list of media.
            //
            Media.Clear();

            //! Enumerate all image resources.
            //
            foreach (String res in Assembly.GetExecutingAssembly().GetManifestResourceNames())
            {
                if (res.StartsWith(ResourceBasePath))
                {
                    // App.Log("found resource: " + res);
                    //
                    Media.Add(res.Replace(ResourceBasePath, String.Empty));
                }
            }

            Height = Width;

            ScaleDown = 900.0 / Width;
        }

        /// <summary>
        /// Check if the puzzle is solved. A puzzle is solved if each piece is not rotated and is
        /// displayed at the correct location in the puzzle.
        /// </summary>
        ///
        /// <returns>
        /// True if it succeeds, false if it fails.
        /// </returns>
        public Boolean IsSolved()
        {
            //! Check all pieces if not rotated and and the correct spot in the pieces list.
            //
            foreach (Piece piece in PuzzlePieces)
            {
                if (piece.Angle != 0
                    || piece.X != piece.displayX
                    || piece.Y != piece.displayY)
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// Raises the <see cref="E:System.Windows.Forms.Control.Paint" /> event. This method either
        /// paints the puzzle image (if assigned and the preview timer is running) or the individual
        /// puzzle pieces.
        /// </summary>
        ///
        /// <param name="pe"> A <see cref="T:System.Windows.Forms.PaintEventArgs" /> that contains the
        ///                   event data. </param>
        protected override void OnPaint(PaintEventArgs pe)
        {
            //! Sanity Check first (do have we any pieces at all)?
            //
            if (PuzzlePieces.Count == Rows * Cols)
            {
                //! Preview?
                if (puzzleImage != null && previewTimer.Enabled)
                {
                    pe.Graphics.DrawImage(puzzleImage, 0, 0, Width, Height);
                }
                else
                {
                    //! Paint all pieces at their display location.
                    //
                    foreach (Piece piece in PuzzlePieces)
                    {
                        Int32 r = piece.displayY;
                        Int32 c = piece.displayX;

                        //! Paint all columns.
                        //
                        float x = (float)((piece.bmp.Width * c) / ScaleDown);
                        float y = (float)((piece.bmp.Height * r) / ScaleDown);

                        float w = (float)(piece.bmp.Width / ScaleDown);
                        float h = (float)(piece.bmp.Height / ScaleDown);

                        pe.Graphics.DrawImage(piece.bmp, x, y, w, h);

                        if (Enabled)
                        {
                            pe.Graphics.DrawRectangle(new Pen(new SolidBrush(Color.Blue)), x, y, w, h);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Executes the move performed operation. It will invoke the OnMovePerformed if assigned.
        /// </summary>
        private void DoMovePerformed()
        {
            OnMovePerformed?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// Executes the solved operation. It will invoke the OnSolved if assigned.
        /// </summary>
        private void DoSolved()
        {
            OnSolved?.Invoke(this, EventArgs.Empty);
        }

        /// <summary>
        /// Event handler. Called by PreviewTimer for tick events. This handler will, when elapsed, stop
        /// the timer and force a repaint of the puzzle showing the pieces instead of the preview image.
        /// </summary>
        ///
        /// <param name="sender"> Source of the event. </param>
        /// <param name="e">      Event information. </param>
        private void PreviewTimer_Tick(object sender, EventArgs e)
        {
            previewTimer.Stop();
            Invalidate();
        }

        /// <summary>
        /// Event handler. Called by pictureBox1 for double click events. It will use the mouse location
        /// to determine the puzzle piece, will rotate the piece 180' and increment the number of moves.
        /// </summary>
        ///
        /// <param name="sender"> Source of the event. </param>
        /// <param name="e">      Event information. </param>
        private void puzzle_DoubleClick(object sender, EventArgs e)
        {
            if (!Enabled)
            {
                return;
            }

            //! Determine the piece clicked. Note: MousePosition fails when debugging this method.
            //
            MouseEventArgs me = (MouseEventArgs)e;

            //! Use Display Location.
            //
            Int32 x = (Cols * me.X / this.Width);
            Int32 y = (Rows * me.Y / this.Height);
            Int32 ndx = PuzzlePieces.FindIndex(p => p.displayX == x && p.displayY == y);

            //Debug.WriteLine($"Rotate Piece {pieces[ndx].X}x{pieces[ndx].Y}, Index: {ndx}");

            //! Rotate piece 180'.
            //
            RotatePiece(ndx);

            //! Adjust rest of UI.
            //
            MyMoves++;

            //! Repaint.
            //
            this.Invalidate();

            DoMovePerformed();

            //! Check if Solved.
            //
            if (IsSolved())
            {
                DoSolved();
            }
        }

        /// <summary>
        /// Event handler. Called by pictureBox1 for drag drop events. It will use the Drop location
        /// to determine the puzzle piece that needs to be swapped with the dragged piece. 
        /// </summary>
        ///
        /// <param name="sender"> Source of the event. </param>
        /// <param name="e">      Drag event information. </param>
        private void puzzle_DragDrop(object sender, DragEventArgs e)
        {
            Debug.WriteLine("DragDrop()");

            if (e.Data.GetData(typeof(Int32)) != null)
            {
                //! Get the Source piece from DnD data (Index of Display Location originated from MouseDown Event).
                //
                Int32 sourceNdx = (Int32)(e.Data.GetData(typeof(Int32)));

                //! Use Display Location.
                //
                Point l = this.PointToClient(new Point(e.X, e.Y));

                Int32 x = (Cols * l.X / this.Width);
                Int32 y = (Rows * l.Y / this.Height);
                Int32 targetNdx = PuzzlePieces.FindIndex(p => p.displayX == x && p.displayY == y);

                //! Bail-out if no move (Source==Destination).
                //
                if (sourceNdx == targetNdx)
                {
                    return;
                }

                //Debug.WriteLine($"Src={sourceNdx} ({pieces[sourceNdx].X}x{pieces[sourceNdx].Y}), Target={targetNdx} ({pieces[targetNdx].X}x{pieces[targetNdx].Y})");

                ////! Swap Pieces.
                ////
                SwapPieces(sourceNdx, targetNdx);

                //! Update rest of UI.
                //
                MyMoves++;

                //! Repaint.
                //
                this.Invalidate();

                DoMovePerformed();

                //! Check if Solved.
                //
                if (IsSolved())
                {
                    DoSolved();
                }
            }
        }

        /// <summary>
        /// Event handler. Called by pictureBox1 for drag enter events.
        /// </summary>
        ///
        /// <param name="sender"> Source of the event. </param>
        /// <param name="e">      Drag event information. </param>
        private void puzzle_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetData(typeof(Int32)) != null)
            {
                e.Effect = DragDropEffects.Move;
            }
        }

        /// <summary>
        /// Event handler. Called by pictureBox1 for drag over events.
        /// </summary>
        ///
        /// <param name="sender"> Source of the event. </param>
        /// <param name="e">      Drag event information. </param>
        private void puzzle_DragOver(object sender, DragEventArgs e)
        {
            if (e.Data.GetData(typeof(Int32)) != null)
            {
                e.Effect = DragDropEffects.Move;
            }
        }

        /// <summary>
        /// Event handler. Called by pictureBox1 for mouse down events. This event is used to start a
        /// Drag and Drop operations. The mouse location is used to determine the puzzle pieces that
        /// should be dragged.
        /// </summary>
        ///
        /// <param name="sender"> Source of the event. </param>
        /// <param name="e">      Mouse event information. </param>
        private void puzzle_MouseDown(object sender, MouseEventArgs e)
        {
            if (Enabled && e.Button == MouseButtons.Left && e.Clicks == 1)
            {
                Point l = e.Location;

                //! Use Display Location.
                //
                Int32 x = (Cols * l.X / this.Width);
                Int32 y = (Rows * l.Y / this.Height);
                Int32 ndx = PuzzlePieces.FindIndex(p => p.displayX == x && p.displayY == y);

                if (ndx != -1)
                {
                    Debug.WriteLine($"Dragging Piece {x}x{y} from Index {ndx}");

                    this.DoDragDrop(ndx, DragDropEffects.Move);
                }
            }
        }

        /// <summary>
        /// Event handler. Called by puzzle1 for mouse move events.
        /// </summary>
        ///
        /// <param name="sender"> Source of the event. </param>
        /// <param name="e">      Mouse event information. </param>
        private void puzzle_MouseMove(object sender, MouseEventArgs e)
        {
            Point l = e.Location;

            // Debug.Print($"{l}");

            Int32 x = (Cols * l.X / this.Width);
            Int32 y = (Rows * l.Y / this.Height);
            Int32 ndx = PuzzlePieces.FindIndex(p => p.X == x && p.Y == y);
        }

        /// <summary>
        /// Rotate a puzzle piece 180'.
        /// </summary>
        ///
        /// <param name="srcNdx"> Source ndx. </param>
        private void RotatePiece(Int32 srcNdx)
        {
            Piece piece = PuzzlePieces[srcNdx];

            piece.bmp.RotateFlip(RotateFlipType.Rotate180FlipNone);
            piece.Angle = (piece.Angle + 180) % 360;

            PuzzlePieces[srcNdx] = piece;
        }

        /// <summary>
        /// Swap two puzzle pieces.
        /// </summary>
        ///
        /// <param name="srcNdx"> Source ndx. </param>
        /// <param name="dstNdx"> Destination ndx. </param>
        private void SwapPieces(Int32 srcNdx, Int32 dstNdx)
        {
            //! Swap Src and Dest Pieces by swapping Display Location.
            //
            Int32 dX = PuzzlePieces[dstNdx].displayX;
            Int32 dY = PuzzlePieces[dstNdx].displayY;

            PuzzlePieces[dstNdx].displayX = PuzzlePieces[srcNdx].displayX;
            PuzzlePieces[dstNdx].displayY = PuzzlePieces[srcNdx].displayY;

            PuzzlePieces[srcNdx].displayX = dX;
            PuzzlePieces[srcNdx].displayY = dY;
        }

        #endregion Methods
    }
}