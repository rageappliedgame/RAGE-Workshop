﻿//! Enabled the Bridge.
//! Enabled the ILog interface implementation.
// 
//#define STEP1

//! Enabled the IDataStorage interface implementation.
// 
//#define STEP3

namespace JCSG_Puzzle
{
#if STEP1
    using AssetPackage;
    using System.Diagnostics;
#if STEP3
    using System.IO;
#endif

    /// <summary>
    /// A bridge class used to supply an ILog and IDataStorage implementation to a RAGE component.
    /// </summary>
    public class Bridge
#if STEP1
        : IBridge, ILog
#endif
#if STEP3
        ,IDataStorage
#endif
    {
#if STEP1
    #region ILog

        /// <summary>
        /// Executes the log operation.
        /// 
        /// Implement this in Game Engine Code.
        /// </summary>
        ///
        /// <param name="severity"> The severity. </param>
        /// <param name="msg">      The message. </param>
        public void Log(Severity severity, string msg)
        {
            Debug.WriteLine($"{severity} - {msg}");
        }

    #endregion
#endif

#if STEP3
    #region IDataStorage

        /// <summary>
        /// Deletes the given fileId.
        /// </summary>
        ///
        /// <param name="fileId"> The file identifier to delete. </param>
        ///
        /// <returns>
        /// true if it succeeds, false if it fails.
        /// </returns>
        public bool Delete(string fileId)
        {
            if (File.Exists(fileId))
            {
                File.Delete(fileId);

                return true;
            }

            return false;
        }

        /// <summary>
        /// Check if exists the file with the given identifier.
        /// </summary>
        ///
        /// <param name="fileId"> The file identifier to delete. </param>
        ///
        /// <returns>
        /// true if it succeeds, false if it fails.
        /// </returns>
        public bool Exists(string fileId)
        {
            return File.Exists(fileId);
        }

        /// <summary>
        /// Gets the files.
        /// </summary>
        ///
        /// <remarks>
        /// A List&lt;String&gt; gave problems when compiled as PCL and added to a Xamarin Forms project
        /// containing iOS, Android and WinPhone subprojects.
        /// </remarks>
        ///
        /// <returns>
        /// An array of filenames.
        /// </returns>
        public string[] Files()
        {
            throw new System.NotImplementedException();
        }

        /// <summary>
        /// Loads the given file.
        /// </summary>
        ///
        /// <param name="fileId"> The file identifier to load. </param>
        ///
        /// <returns>
        /// A String with with the file contents.
        /// </returns>
        public string Load(string fileId)
        {
            return File.Exists(fileId)
                ? File.ReadAllText(fileId)
                : null;
        }

        /// <summary>
        /// Saves the given file.
        /// </summary>
        ///
        /// <param name="fileId">   The file identifier to delete. </param>
        /// <param name="fileData"> Information describing the file. </param>
        public void Save(string fileId, string fileData)
        {
            File.WriteAllText(fileId, fileData);
        }

    #endregion
#endif

    }
#endif
}
