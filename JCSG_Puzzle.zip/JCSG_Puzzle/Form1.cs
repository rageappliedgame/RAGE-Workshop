﻿//! Setup JCSG_Puzzle Solution.
//! 1) Add references:
//!  a) Add reference to AssetManager project (the RageAssetManager.csproj file).
//!  b) Add reference to TwoA project (the TwoA.csproj file).

//! Integrate and Setting up TwoA.
//!  1) In Form_Load (at program startup) we Setup TwoA:
//!   a) We add a scenario for each puzzle level with a default difficulty of 1.
//!   b) We add a single player with a default skill of 1.1. 
//!   c) Uncomment the #define STEP1 line in Bridge.cs as well.
//#define STEP1

//! Using TwoA.
//!  1) In order to use TwoA we:
//!   a) Use TwoA to select a next suitable scenario.
//!   b) After completion of a Puzzle we ask TwoA to update it's scenario ratings and player skills. 
//! Visualization in Chart.
//!  1) To Visualize TwoA's changes to scenario ratings and player skills we visualize them in a bar chart.
//!   a) Bars represent scenarios, 
//!   b) The horizontal marker is the player's skill.
//!   c) The vertical marker is the level being (or just) played. 
//!   d) The current scenario bar is red if it became more difficult and green if it became easier.
//!   e) The Bar's tooltip show the current level info.
//#define STEP2

//! Saving TwoA Data after level completion.
//!  1) Data is stored in Xml Format.
//!   a) Scenario Data.
//!   b) Player Data.
//!   c) Historical Data on Game Play.
//!   d) Uncomment the #define STEP3 line in Bridge.cs as well.
//! Loading TwoA Data at startup.
//!  1) Data is loaded from Xml Format (if file is present).
//!   a) Scenario Data.
//!   b) Player Data.
//!   c) Historical Data on Game Play.
//#define STEP3

//! The method GeneratePuzzles() and SelectNextLevel(String nextLevelID) are the spots where to further tweak this puzzle game.
//!  1) Generate more puzzles per scenario ID.
//!  2) Generate larger puzzles.

namespace JCSG_Puzzle
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Drawing;
    using System.Linq;
    using System.Windows.Forms;
    using System.Windows.Forms.DataVisualization.Charting;

    using JCSG_Puzzle.Model;

#if STEP1
    using TwoANS;
#endif

    /// <summary>
    /// A form 1.
    /// </summary>
    public partial class Form1 : Form
    {
        #region Fields

        /// <summary>
        /// Full pathname of the resource base file.
        /// </summary>
        private const String ResourceBasePath = "JCSG_Puzzle.Media.";

#if STEP1
        /// <summary>
        /// Identifier for the adapt.
        /// </summary>
        String adaptID = DifficultyAdapter.Type;

        /// <summary>
        /// Identifier for the game.
        /// </summary>
        String gameID = "Puzzle";

        /// <summary>
        /// Using this player as an example.
        /// </summary>
        String playerID = "Noob";

        /// <summary>
        /// The TwoA asset.
        /// </summary>
        TwoA twoA = new TwoA(new Bridge());
#endif

#if !STEP2
        /// <summary>
        /// The available number of moves.
        /// </summary>
        List<Int32> Moves = new List<Int32>();

        /// <summary>
        /// The moves index.
        /// </summary>
        Int32 MovesNdx = 0;
#endif

#if STEP2
        /// <summary>
        /// The old ratings. Used for coloring the bars in the scenarios bar graph.
        /// </summary>
        List<Double> previousScenarioRatings = new List<Double>();
#endif

        /// <summary>
        /// The puzzle level definitions.
        /// </summary>
        private List<Level> Levels = new List<Level>();

        /// <summary>
        /// The stopwatch to measure the elapsed time of puzzle completion.
        /// </summary>
        Stopwatch sw = new Stopwatch();

        /// <summary>
        /// The random number generator.
        /// </summary>
        private Random rand = new Random();

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Default constructor.
        /// </summary>
        public Form1()
        {
            InitializeComponent();
        }

        #endregion Constructors

        #region Methods

        /// <summary>
        /// Event handler. Called by button1 for click events.
        /// </summary>
        ///
        /// <param name="sender"> Source of the event. </param>
        /// <param name="e">      Event information. </param>
        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = String.Empty;
            label2.Text = String.Empty;


#if STEP2
            String nextLevelID = twoA.TargetScenarioID(adaptID, gameID, playerID);
#else
            String nextLevelID = MovesNdx.ToString();
#endif

            toolStripStatusLabel1.Text = $"Level: {nextLevelID}";

            Level nextLevel = SelectNextLevel(nextLevelID);

            toolStripStatusLabel2.Text = $"Puzzle: {nextLevel}";

#if STEP2
            previousScenarioRatings = twoA.AllScenarios(adaptID, gameID)
                .OrderBy(p => p.ScenarioID)
                .Select(p => p.Rating).ToList();

            //! Make use of the ScenarioID being alphabetical sortable
            //! NOTE: This sorting is only necessary for positioning the vertical cross hair.
            //
            List<ScenarioNode> scenarios = twoA.AllScenarios(adaptID, gameID).OrderBy(p => p.ScenarioID).ToList();

            Int32 ndx = scenarios.FindIndex(p => p.ScenarioID.Equals(nextLevelID));

            chart1.ChartAreas[0].CursorX.Position = ndx + 1;

            UpdateChart();
#endif
            puzzle1.CreatePuzzle(nextLevel);

            (sender as Button).Enabled = false;

            puzzle1.Enabled = true;

            sw.Reset();
            sw.Start();
        }

        /// <summary>
        /// Event handler. Called by button2 for on click events.
        /// </summary>
        ///
        /// <param name="sender"> Source of the event. </param>
        /// <param name="e">      Event information. </param>
        private void button2_Click(object sender, EventArgs e)
        {
#if STEP3
            twoA.players.Clear();
            twoA.SavePlayerData();

            twoA.scenarios.Clear();
            twoA.SaveScenarioData();

            twoA.gameplays.Clear();
            twoA.SaveGamePlayData();

            SetupTwoA();
#endif
            button1.Enabled = true;
        }

        /// <summary>
        /// Event handler. Called by chart1 for get tool tip text events.
        /// </summary>
        ///
        /// <param name="sender"> Source of the event. </param>
        /// <param name="e">      Tool tip event information. </param>
        private void chart1_GetToolTipText(object sender, System.Windows.Forms.DataVisualization.Charting.ToolTipEventArgs e)
        {
            switch (e.HitTestResult.ChartElementType)
            {
                case ChartElementType.DataPoint:
                    e.Text = e.HitTestResult.Series.Points[e.HitTestResult.PointIndex].ToolTip;
                    break;
            }
        }

        /// <summary>
        /// Event handler. Called by Form1 for load events.
        /// </summary>
        ///
        /// <param name="sender"> Source of the event. </param>
        /// <param name="e">      Event information. </param>
        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = String.Empty;
            label2.Text = String.Empty;

            GeneratePuzzles();

#if STEP1
            SetupTwoA();
#endif

#if STEP3
            twoA.LoadGamePlayData();

            //if (File.Exists(GamePlaysDataFile))
            //{
            //    LoadGamePlayData();

            //    foreach (Gameplay g in twoA.gameplays)
            //    {
            //        Debug.Print($"{g.PlayerRating}");
            //    }
            //}
#endif

            chart1.ChartAreas[0].CursorX.IsUserEnabled = false;
            chart1.ChartAreas[0].CursorX.IsUserSelectionEnabled = false;

            chart1.ChartAreas[0].CursorX.LineColor = Color.Red;
            chart1.ChartAreas[0].CursorX.LineWidth = 1;

            chart1.ChartAreas[0].AxisX.Title = "Level Index";
            chart1.ChartAreas[0].AxisY.Title = "Level Difficulty";
            //chart1.ChartAreas[0].AxisY2.Title = "Player Skill";

            //! Load PuzzleImages.
            //
            puzzle1.InitPuzzle(ResourceBasePath);
        }

        /// <summary>
        /// Generates a set of 2x2 puzzles.
        /// </summary>
        private void GeneratePuzzles()
        {
            //! Generate all puzzles up to Cols x Rows cells with all allowed swaps/rotates.
            //
            //! The max number of Swaps is half the number of pieces (as the code will swap pieces two at a time).
            //! The max number of Rotates is the number of pieces.
            //
            //! NOTE: For up to 2x2 pieces (so 1x2 and 2x2) there are 24 possible 'levels',
            //!       as 0 swaps and 0 rotates or only 1 piece are not allowed.
            //!       These would results in puzzles that need zero moves to solve.
            //
            // 1 move required: 1 swap
            Levels.Add(new Level()
            {
                Swaps = 1,
                Rotates = 0,
                LevelID = "1",
            });

            // [SC] 2 moves required: 1 swap and 1 rotation
            Levels.Add(new Level()
            {
                Swaps = 1,
                Rotates = 1,
                LevelID = "2",
            });

            // [SC] 3 moves required: 2 swaps and 1 rotation
            Levels.Add(new Level()
            {
                Swaps = 2,
                Rotates = 1,
                LevelID = "3",
            });

            // [SC] 4 moves required: 2 swaps and 2 rotations
            Levels.Add(new Level()
            {
                Swaps = 2,
                Rotates = 2,
                LevelID = "4",
            });

            // [SC] 5 moves required: 2 swaps and 3 rotations
            Levels.Add(new Level()
            {
                Swaps = 2,
                Rotates = 3,
                LevelID = "5",
            });

            // [SC] 6 moves required: 2 swaps and 4 rotations
            Levels.Add(new Level()
            {
                Swaps = 2,
                Rotates = 4,
                LevelID = "6",
            });

            // [SC] Sorting is only required for the chart visualizing the levels and their actual difficulty.
            Levels = Levels.OrderBy(p => p.Rotates + p.Swaps).Distinct().ToList();
#if !STEP2
            // For puzzling without TwoA we just take the next number of moves when the puzzle is solved
            // perfectly. 
            Moves = Levels.Select(p => p.Moves).ToList();
            MovesNdx = 0;
#endif
        }

        /// <summary>
        /// Event handler. Called by puzzle1 for on move performed events.
        /// </summary>
        ///
        /// <param name="sender"> Source of the event. </param>
        /// <param name="e">      Event information. </param>
        private void puzzle1_OnMovePerformed(object sender, EventArgs e)
        {
            label1.Text = puzzle1.Score;
            label2.Text = puzzle1.Result;
        }

        /// <summary>
        /// Event handler. Called by puzzle1 for on solved events.
        /// </summary>
        ///
        /// <param name="sender"> Source of the event. </param>
        /// <param name="e">      Event information. </param>
        private void puzzle1_OnSolved(object sender, EventArgs e)
        {
            puzzle1.Enabled = false;

            sw.Stop();

#if STEP2
            Double secs = sw.ElapsedMilliseconds;

            twoA.UpdateRatings(adaptID, gameID, playerID, puzzle1.PuzzleID,
                secs,
                puzzle1.Moves == puzzle1.MyMoves ? 1 : 0,
                true,
                0);
#else
            if (puzzle1.MyMoves == puzzle1.Moves)
            {
                MovesNdx = Math.Min(Moves.Count - 1, MovesNdx + 1);
            }
            else
            {
                // MovesNdx remains unchanged
            }

#endif
            Refresh();

            UpdateChart();

            button1.Enabled = true;
        }

        /// <summary>
        /// Sets up the TwoA component by defining levels, and a player.
        /// </summary>
        private void SetupTwoA()
        {
#if STEP3
            //! (Re)Load Scenario Data
            //
            twoA.LoadScenarioData();

            if (twoA.scenarios.Count == 0)
#endif
#if STEP1
            //! Ass Scenario Data.
            // 
            {
                twoA.SetCalLength(adaptID, 100);

                //! Add Difficulty Levels
                foreach (String levelID in Levels.Select(p => p.LevelID).Distinct())
                {
                    twoA.AddScenario(new ScenarioNode(adaptID, gameID, levelID)
                    {
                        // starting difficulty rating is 1
                        Rating = 1.0,
                        // player is given 10 000 milliseconds to solve the puzzle
                        TimeLimit = 10 * 1000,
                    });
                }
            }
#endif

#if STEP3
            //! (Re)Load Player Data
            //
            twoA.LoadPlayerData();

            if (twoA.players.Count == 0)
#endif
#if STEP1
            {
                //! Add Player
                //
                twoA.AddPlayer(new PlayerNode(adaptID, gameID, playerID)
                {
                    // [SC] player's starting rating is 1.1
                    Rating = 1.1,
                });
            }
#endif
        }

        /// <summary>
        /// Updates the chart. If a bar is growing it's colored red, if shrinking green else it has a
        /// default blue color. The vertical red marker indicates the level played, the horizontal marker
        /// shows the player's skill level.
        /// </summary>
        private void UpdateChart()
        {
#if STEP2
            List<ScenarioNode> scenarios = twoA.AllScenarios(adaptID, gameID)
               .OrderBy(p => p.ScenarioID)
               .ToList();

            List<Double> ratings = scenarios.Select(p => p.Rating).ToList();
            List<String> ids = scenarios.Select(p => p.ScenarioID).ToList();

            chart1.Series.SuspendUpdates();
            chart1.Series[0].Points.Clear();
            for (Int32 i = 0; i < ratings.Count; i++)
            {
                Double scenarioRating = ratings[i];

                Int32 ndx = chart1.Series[0].Points.AddY(scenarioRating);

                chart1.Series[0].Points[ndx].ToolTip = ids[i];

                if (previousScenarioRatings.Count == ratings.Count
                    && scenarioRating != previousScenarioRatings[i])
                {
                    chart1.Series[0].Points[ndx].Color = scenarioRating > previousScenarioRatings[i]
                        ? Color.Red
                        : Color.Green;
                }
                else
                {
                    //! See https://blogs.msdn.microsoft.com/alexgor/2009/10/06/setting-microsoft-chart-series-colors/
                    //! This is the default color of the current BrightPastel Chart Palette (blue-ish).
                    //
                    //chart1.Series[0].Points[i].Color = Color.FromArgb(255, 65, 140, 240);
                }
            }

            Double playerRating = twoA.AllPlayers(adaptID, gameID).Where(p => p.PlayerID.Equals(playerID)).First().Rating;

            //Debug.Print($"Player Rating: {playerRating}");

            chart1.ChartAreas[0].AxisY.Maximum = 3;

            chart1.ChartAreas[0].CursorY.IsUserEnabled = false;
            chart1.ChartAreas[0].CursorY.IsUserSelectionEnabled = false;

            chart1.ChartAreas[0].CursorY.Position = playerRating;
            chart1.ChartAreas[0].CursorY.LineColor = Color.Red;
            chart1.ChartAreas[0].CursorY.LineWidth = 1;

            chart1.Series.ResumeUpdates();
#endif
        }

        /// <summary>
        /// Select next level. If there are more then one puzzle sharing the same specified next levelID,
        /// a random one is selected.
        /// </summary>
        ///
        /// <param name="nextLevelID"> Identifier for the next level. </param>
        ///
        /// <returns>
        /// A Level.
        /// </returns>
        private Level SelectNextLevel(String nextLevelID)
        {
            Debug.Print($"Requested new Level: {nextLevelID}");

#if STEP2
            //! Select all puzzles in the next level.
            //
            List<Level> levelsList = Levels.FindAll(p => p.LevelID.Equals(nextLevelID)).ToList();
#else
            List<Level> levelsList = Levels.FindAll(p => p.Moves.Equals(Moves[Int32.Parse(nextLevelID)])).ToList();
#endif
            Debug.Print($"Requested new Level contains: {levelsList.Count} definition(s)");

            //! Select a random puzzle of the next level.
            //
            Level nextLevel = levelsList[rand.Next(levelsList.Count)];

            Debug.Print($"New Level Definition: {nextLevel}");

            return nextLevel;
        }

        /// <summary>
        /// Event handler. Called by Form1 for form closing events.
        /// </summary>
        ///
        /// <param name="sender"> Source of the event. </param>
        /// <param name="e">      Form closing event information. </param>
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
#if STEP3
            twoA.SavePlayerData();
            twoA.SaveScenarioData();
            twoA.SaveGamePlayData();
#endif
        }

        #endregion
    }
}